
import React from 'react';
import type { StyleOptions } from '../App';

interface TablePreviewProps {
  data: string[][];
  styleOptions: StyleOptions;
  onRowClick: (index: number) => void;
}

const TablePreview: React.FC<TablePreviewProps> = ({ data, styleOptions, onRowClick }) => {
  if (data.length === 0 || (data.length === 1 && data[0].length <= 1 && data[0][0] === '')) {
    return (
      <div className="flex items-center justify-center h-64 border-2 border-dashed border-gray-300 rounded-lg bg-gray-50">
        <p className="text-gray-500 text-center p-4">Table preview will appear here once you paste data.</p>
      </div>
    );
  }

  const {
      hasHeader,
      borderColor,
      headerBgColor,
      textAlign,
      fontFamily,
      fontColor,
      fontSize,
      cellPadding,
      headerBold,
      headerItalic,
      headerUnderline,
      enableZebraStriping,
      zebraStripeColor,
      highlightedRowIndex,
      highlightedRowColor
  } = styleOptions;

  const headerData = hasHeader ? (data[0] || []) : [];
  const bodyData = hasHeader ? data.slice(1) : data;

  const fontSizeMap: { [key: string]: string } = {
    small: '14px',
    medium: '16px',
    large: '18px',
    xlarge: '20px',
  };
  const actualFontSize = fontSizeMap[fontSize] || '16px';

  const tableStyle: React.CSSProperties = {
    borderCollapse: 'collapse',
    width: '100%',
    fontFamily: fontFamily,
    fontSize: actualFontSize,
  };

  const cellStyle: React.CSSProperties = {
    border: `1px solid ${borderColor}`,
    padding: `${cellPadding}px`,
    textAlign: textAlign,
    color: fontColor,
  };

  const headerCellStyle: React.CSSProperties = {
      ...cellStyle,
      backgroundColor: headerBgColor,
      fontWeight: headerBold ? 'bold' : 'normal',
      fontStyle: headerItalic ? 'italic' : 'normal',
      textDecoration: headerUnderline ? 'underline' : 'none',
  };


  return (
    <div className="overflow-x-auto rounded-lg">
      <style>{`
        .preview-row:hover { background-color: #f1f1f1 !important; }
      `}</style>
      <table style={tableStyle}>
        {hasHeader && headerData.length > 0 && (
          <thead>
            <tr>
              {headerData.map((cell, index) => (
                <th key={index} style={headerCellStyle}>{cell.trim()}</th>
              ))}
            </tr>
          </thead>
        )}
        <tbody>
          {bodyData.map((row, rowIndex) => {
            if (row.every(cell => cell.trim() === '')) return null;

            const isHighlighted = rowIndex === highlightedRowIndex;
            const isZebra = enableZebraStriping && rowIndex % 2 === 1;

            const rowStyle: React.CSSProperties = {};
            if (isHighlighted) {
              rowStyle.backgroundColor = highlightedRowColor;
            } else if (isZebra) {
              rowStyle.backgroundColor = zebraStripeColor;
            }
            
            return (
              <tr 
                key={rowIndex}
                onClick={() => onRowClick(rowIndex)}
                style={rowStyle}
                className={`transition-colors duration-150 cursor-pointer ${!isHighlighted ? 'preview-row' : ''}`}
                >
                {row.map((cell, cellIndex) => (
                  <td key={cellIndex} style={cellStyle}>{cell.trim()}</td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default TablePreview;
