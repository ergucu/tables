
import React from 'react';
import { useState } from 'react';
import CopyIcon from './icons/CopyIcon';
import CheckIcon from './icons/CheckIcon';

interface HtmlOutputProps {
  html: string;
}

const HtmlOutput: React.FC<HtmlOutputProps> = ({ html }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!html) return;
    navigator.clipboard.writeText(html).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  };
  
  const hasContent = html.trim().length > 0;

  return (
    <div className="relative h-full flex flex-col">
       {hasContent && (
        <button
            onClick={handleCopy}
            className="absolute top-3 right-3 z-10 p-2 bg-gray-700 hover:bg-gray-600 rounded-md text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-500 flex items-center space-x-2"
            aria-label="Copy HTML to clipboard"
        >
            {copied ? (
                <CheckIcon className="w-5 h-5 text-green-400" />
            ) : (
                <CopyIcon className="w-5 h-5" />
            )}
            <span className="text-xs">{copied ? 'Copied!' : 'Copy'}</span>
        </button>
      )}
      <pre className="flex-grow h-full p-4 pt-12 bg-gray-800 text-gray-300 rounded-lg overflow-auto text-sm">
        <code className="language-html whitespace-pre-wrap">{html || '<!-- HTML output will appear here -->'}</code>
      </pre>
    </div>
  );
};

export default HtmlOutput;
